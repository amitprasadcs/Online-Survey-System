# online-survey-system-java

This is a project for developing an online survey system using Java. The focus of the project is to build an online platform that can efficiently collect the viewpoints of the target audience of a survey via the internet. This application can launch online surveys and also send email notifications.
